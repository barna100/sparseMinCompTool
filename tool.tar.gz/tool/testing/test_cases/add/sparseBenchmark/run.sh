cd /home/dell/Workspace/benchmark/SuiteSparse/CSparse/testRun
rm Makefile
rm spTest_add.c
ln -s /home/dell/Workspace/tool/testing/test_cases/add/sparseBenchmark/Makefile .
ln -s /home/dell/Workspace/tool/testing/test_cases/add/sparseBenchmark/spTest_add.c .
make
make run
