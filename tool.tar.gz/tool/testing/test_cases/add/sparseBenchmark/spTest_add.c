#include "cs.h"
#include <sys/time.h>
int main (int argc, char **argv)
{
    struct timeval start, end;
    unsigned long ret;
    cs *T, *A, *B, *C ;
    csi i, m ;    
    FILE *f1;
    f1 = fopen(argv[argc-2],"r");	
    T = cs_load (f1) ;               /* load triplet matrix T from stdin */
    A = cs_compress (T) ;               /* A = compressed-column form of T */
    cs_spfree (T) ;                     /* clear T */
    f1 = fopen(argv[argc-1],"r");	
    T = cs_load (f1) ;               /* load triplet matrix T from stdin */
    B = cs_compress (T) ;               /* A = compressed-column form of T */
    cs_spfree (T) ;                     /* clear T */
    gettimeofday(&start,NULL);
    C = cs_add (A, B, 1, 1) ;   
    gettimeofday(&end,NULL);
    ret = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec);
    printf("Time taken : %ld usec\n", ret);
    printf ("C:\n") ; cs_print (C, 0) ; /* print C */
    cs_spfree (A) ;                     
    cs_spfree (B) ;                     
    cs_spfree (C) ;
    return (0) ;
}
