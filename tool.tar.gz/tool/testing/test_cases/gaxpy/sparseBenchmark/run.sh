cd /home/dell/Workspace/benchmark/SuiteSparse/CSparse/testRun
rm Makefile
rm spTest_gaxpy.c
ln -s /home/dell/Workspace/tool/testing/test_cases/gaxpy/sparseBenchmark/Makefile .
ln -s /home/dell/Workspace/tool/testing/test_cases/gaxpy/sparseBenchmark/spTest_gaxpy.c .
make
make run
