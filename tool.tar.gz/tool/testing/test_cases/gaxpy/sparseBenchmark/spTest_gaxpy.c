#include "cs.h"
#include <sys/time.h>
int main (int argc, char **argv)
{
    struct timeval start, end;
    unsigned long ret;
    cs *T, *A, *B, *C ;
    csi m ;    
    FILE *f1;
    double *x, *y;
    int i;
    int row = atoi(argv[argc-3]);
    int col = atoi(argv[argc-2]);
    f1 = fopen(argv[argc-1],"r");	
    T = cs_load (f1) ;               /* load triplet matrix T from stdin */
    A = cs_compress (T) ;               /* A = compressed-column form of T */
    cs_spfree (T) ;                     /* clear T */
    x = cs_malloc(col,sizeof(double));
    y = cs_malloc(col,sizeof(double));
    for (i=0; i<col; i++){
	*(x+i) = i + 1;
	*(y+i) = 0;
    }
    gettimeofday(&start,NULL);
    cs_gaxpy (A, x, y) ;   
    gettimeofday(&end,NULL);
    ret = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec);
    printf("Time taken : %ld usec\n", ret);
//    printf ("A:\n") ; cs_print (A, 0) ; /* print A */
    for (i=0; i<col; i++){
      if (*(y+i) != 0)
	printf("[%d] : %lf\n", i, *(y+i));
    }
    cs_spfree (A) ;                     
    return (0) ;
}
