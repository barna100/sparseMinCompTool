cd /home/dell/Workspace/benchmark/SuiteSparse/CSparse/testRun
rm Makefile
rm spTest_transpose.c
rm A.ip
ln -s /home/dell/Workspace/tool/testing/test_cases/transpose/sparseBenchmark/Makefile .
ln -s /home/dell/Workspace/tool/testing/test_cases/transpose/sparseBenchmark/spTest_transpose.c .
ln -s /home/dell/Workspace/tool/testing/test_cases/transpose/sparseBenchmark/A.ip .
make
make run
