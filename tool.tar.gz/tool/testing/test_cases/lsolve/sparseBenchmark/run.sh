cd /home/dell/Workspace/benchmark/SuiteSparse/CSparse/testRun
rm Makefile
rm spTest_lsolve.c
ln -s /home/dell/Workspace/tool/testing/test_cases/lsolve/sparseBenchmark/Makefile .
ln -s /home/dell/Workspace/tool/testing/test_cases/lsolve/sparseBenchmark/spTest_lsolve.c .
make
make run
