cd /home/dell/Workspace/benchmark/SuiteSparse/CSparse/testRun
rm Makefile
rm spTest_multiply.c
ln -s /home/dell/Workspace/tool/testing/test_cases/multiply/sparseBenchmark/Makefile .
ln -s /home/dell/Workspace/tool/testing/test_cases/multiply/sparseBenchmark/spTest_multiply.c .
make
make run
