#/usr/bin/python
import sys

def write_xData(col,f1):
  f1.write(str(col)+' '+str(col)+'\n')
  for i in range(col):
    f1.write(str(i)+' '+str(i+1)+'\n')

if __name__ == "__main__":
  col = int(sys.argv[len(sys.argv)-2])    
  f1 = open(sys.argv[len(sys.argv)-1],'w')
  write_xData(col,f1)
  f1.close()
