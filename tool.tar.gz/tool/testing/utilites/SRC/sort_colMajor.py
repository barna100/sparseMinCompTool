#/usr/bin/python

import sys
import random
import re

def read_file(f1):
  entryList = []
  for line in f1:
    line = line.strip()
    line = re.sub('\[','',line)
    line = re.sub(']','',line)
    line = re.sub(':','',line)
    line = re.sub('  ',' ',line)
    entry = line.split(' ')
    entryList.append(entry)
  return entryList

def sort_list(list1):
  return sorted(list1,key=lambda x: (int(x[0]),int(x[1])))

def write_file(f2,list1):
  for l in list1:
    f2.write('['+str(l[0])+' '+str(l[1])+'] : '+str(l[2])+'\n')    

if __name__ == "__main__":
  f1 = open(sys.argv[len(sys.argv)-2], "r")    
  entryList = read_file(f1)
  entryList = sort_list(entryList)
  f2 = open(sys.argv[len(sys.argv)-1], "w")    
  write_file(f2,entryList)
  f1.close()
  f2.close()
