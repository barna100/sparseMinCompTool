#/usr/bin/python

import sys

def transpose_sort(fr):
  eList = []
  neList = []
  for line in fr:
    entry = line.strip().split()
    eList.append(entry)
    newEntry = []
    newEntry.append(entry[1])
    newEntry.append(entry[0])
    newEntry.append(entry[2])
    neList.append(newEntry)
  print eList, neList
  return sorted(neList, key = lambda x:(x[0],x[1]))
 
def write_file(fw,list1):
  for l in list1:
    fw.write(l[0]+' '+l[1]+' '+ l[2] +'\n') 
  return fw

if __name__ == "__main__":
  inpFile = sys.argv[len(sys.argv)-1]
  fr = open(inpFile, "r")
  fw = open(inpFile + '.trns', "w")
  inpList = transpose_sort(fr)
  print inpList
  write_file(fw,inpList)
  fr.close()
  fw.close()
